﻿namespace Library.NotificationService2.Configuration
{
    public class RabbitMqConfiguration
    {
        public string ServerAddress { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
