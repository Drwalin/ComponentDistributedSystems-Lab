namespace Library.WebApi.Models
{
    public class LibraryResource
    {
        public int Id { get; set; }
        public Book Book { get; set; }
    }
}